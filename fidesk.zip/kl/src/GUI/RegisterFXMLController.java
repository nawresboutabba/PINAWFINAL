/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXTextField;
import Entities.FosUser;
import Services.FosUserServices;
import utils.ConnexionBD;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class RegisterFXMLController implements Initializable {

       @FXML
    private JFXTextField tctusername;

    @FXML
    private JFXTextField txtemail;
    @FXML
    private JFXTextField txtconf;
    @FXML
    private JFXTextField txtpassword;



    @FXML
    private Label pwverif;


    Connection conn = ConnexionBD.getInstance().getCnx();
    @FXML
    private Label confpass;
    @FXML
    private Label testmail;
    @FXML
    private Label testusername;
   
 
    @FXML
    private Label errorReg;

    public RegisterFXMLController() {

    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       /* List<String> sexe = new ArrayList<>();
        sexe.add("Femme");
        sexe.add("Homme");
        sexelist = FXCollections.observableList(sexe);
        cbgenre.setItems(sexelist);

        ObservableList<String> countries = Stream.of(Locale.getISOCountries())
                .map(locales -> new Locale("", locales))
                .map(Locale::getDisplayCountry)
                .collect(Collectors.toCollection(FXCollections::observableArrayList));

        txtpays.setItems(countries);
  */
    }

    @FXML
    private void AjouterUser(ActionEvent event) throws SQLException, IOException {
        FosUserServices fs = new FosUserServices();
        FosUser u = new FosUser();

        if ((testusername.getText().equals("Pseudo valide")) && (testmail.getText().equals("Email valide")) && (pwverif.getText().equals("Mot de passe valide"))
                && (confpass.getText().equals("Mot de passe confirmé")) ) 
                 {

            u.setUsername(tctusername.getText());
            u.setUsernameCanonical(tctusername.getText());
            u.setEmail(txtemail.getText());
            u.setEmailCanonical(txtemail.getText());
            u.setPassword(txtpassword.getText());
            //u.setPhone(txtphone.getText());
            fs.create(u);
            System.out.println("Ajout effectué avec succès");
            Parent home_page_parent = FXMLLoader.load(getClass().getResource("LoginFXML.fxml"));
            Scene home_page_scene = new Scene(home_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.hide(); //optional
            app_stage.setScene(home_page_scene);
            app_stage.show();

        } else {
            errorReg.setText("Veuillez vérifier vos données !! ");

        }

    }

    public static boolean validPassword(String password) {
        if (password.length() > 7) {
            return true;

        }
        return false;
    }

    public static boolean checkPassword(String password) {
        boolean hasNum = false;
        boolean hasCap = false;
        boolean hasLow = false;
        char c;
        for (int i = 0; i < password.length(); i++) {
            c = password.charAt(i);
            if (Character.isDigit(c)) {
                hasNum = true;
            } else if (Character.isUpperCase(c)) {
                hasCap = true;
            } else if (Character.isLowerCase(c)) {
                hasLow = true;
            }
            if (hasCap && hasLow && hasNum) {
                return true;
            }
        }
        return false;
    }

    @FXML
    private void pw(MouseEvent event) {

        if (!validPassword(txtpassword.getText())) {
            pwverif.setTextFill(Paint.valueOf("RED"));
            pwverif.setText("Le mot de passe doit contenir plus que 7 caractères.");
        } else if (!checkPassword(txtpassword.getText())) {
            pwverif.setTextFill(Paint.valueOf("RED"));
            pwverif.setText("Le mot de passe doit contenir des lettres en majuscule, en miniscule ainsi que des chiffres.");
        } else {
            pwverif.setTextFill(Paint.valueOf("#0000FF"));
            pwverif.setText("Mot de passe valide");
        }
    }

    public static boolean confPassword(String password, String conf) {

        if (password.equals(conf)) {

            return true;
        }

        return false;
    }

    @FXML
    private void ConfPw(MouseEvent event) {
        if (confPassword(txtpassword.getText(), txtconf.getText())) {

            confpass.setTextFill(Paint.valueOf("#0000FF"));
            confpass.setText("Mot de passe confirmé");

        } else if (!confPassword(txtpassword.getText(), txtconf.getText())) {

            confpass.setTextFill(Paint.valueOf("RED"));
            confpass.setText("Le mot de passe et la confirmation ne sont pas identiques.");

        }
    }

    public boolean checkMail(String a) {

        Boolean valide = false;
        int i, j, k;
        for (j = 1; j < a.length(); j++) {
            if (a.charAt(j) == '@') {
                if (j < a.length() - 4) {
                    for (k = j; k < a.length() - 2; k++) {
                        if (a.charAt(k) == '.') {
                            valide = true;
                        }
                    }
                }
            }
        }

        return valide;
    }

    @FXML
    private void verifMail(MouseEvent event) {
        FosUserServices fs = new FosUserServices();
        if (checkMail(txtemail.getText())) {
            if (fs.CheckIfUserExist(txtemail.getText())) {
                testmail.setTextFill(Paint.valueOf("RED"));
                testmail.setText("Utilisateur existe déjà ");
            } else {
                testmail.setTextFill(Paint.valueOf("#0000FF"));
                testmail.setText("Email valide");
            }
        } else {
            testmail.setTextFill(Paint.valueOf("RED"));
            testmail.setText("Vérifiez le format de votre adresse mail ");
        }

    }

    public static boolean checkUsername(String username) {

        if (username.matches("\\b[a-zA-Z][a-zA-Z0-9\\-._]{3,}\\b")) {
            return true;
        }

        return false;
    }

    @FXML
    private void verifUsername(MouseEvent event) {
        FosUserServices fs = new FosUserServices();
        if (checkUsername(tctusername.getText())) {
            if (fs.CheckIfUsernameExist(tctusername.getText())) {
                testusername.setTextFill(Paint.valueOf("RED"));
                testusername.setText("Pseudo existe déjà ");
            } else {
                testusername.setTextFill(Paint.valueOf("#0000FF"));
                testusername.setText("Pseudo valide");

            }

        } else {
            testusername.setTextFill(Paint.valueOf("RED"));
            testusername.setText("Vérifiez le format de votre pseudo ");
        }

    }

  

}
