/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Entities.Suggestion;
import Services.SuggestionService;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Memmicha
 */
public class AfficherSuggBackController implements Initializable {

    @FXML
    private TableView<Suggestion> table;
    @FXML
    private TableColumn<Suggestion, String> Fondation;
    @FXML
    private TableColumn<Suggestion, String> Description;
    @FXML
    private TableColumn<Suggestion, String> Mail;
    @FXML
    private TableColumn<?, ?> id;

    @FXML
    private AnchorPane chercher;
    @FXML 
    private Button search;
    @FXML 
    private TextField fondation;
    @FXML
    private TextField description;
    @FXML
    private TextField mail;
    @FXML 
    private JFXButton logout;
    @FXML 
    private TextField ch;
     @FXML
    private JFXButton btn_chart;
    
    @FXML
    private JFXButton btn_Feed;
    @FXML
    private JFXButton btn_Sugg;

    @FXML
    private JFXButton btn_home;
    @FXML
    private Label names;
    
    @FXML
    private Button Supprimer;
    @FXML
    private Button Ajouter;
    @FXML 
    private Button modifier;
   

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         SuggestionService sv = new SuggestionService();
       ObservableList<Suggestion> list = FXCollections.observableArrayList();
        try {
            for (Suggestion bb : sv.afficherSuggestion()) {
                list.add(bb);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AfficherSuggBackController.class.getName()).log(Level.SEVERE, null, ex);
        }

        //mettre les données dans la table view:    
        
        Fondation.setCellValueFactory(new PropertyValueFactory<>("fondation"));
        Description.setCellValueFactory(new PropertyValueFactory<>("description"));
        Mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
        table.setItems(list);
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if ((event.getSource() == btn_Feed)) {
            try {
                javafx.scene.Parent tableview = FXMLLoader.load(getClass().getResource("affich.fxml"));
                Scene sceneview = new Scene(tableview);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(sceneview);
                window.show();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        } else if (event.getSource() == btn_Sugg) {
            try {
                javafx.scene.Parent tableview = FXMLLoader.load(getClass().getResource("AfficherSuggBack.fxml"));
                Scene sceneview = new Scene(tableview);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(sceneview);
                window.show();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        } else if (event.getSource() == btn_home) {
            try {
                javafx.scene.Parent tableview = FXMLLoader.load(getClass().getResource("back.fxml"));
                Scene sceneview = new Scene(tableview);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(sceneview);
                window.show();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
         else if (event.getSource() == btn_chart) {
           try {
        javafx.scene.Parent tableview = FXMLLoader.load(getClass().getResource("statistiqueInscriptions.fxml"));
        Scene sceneview = new Scene(tableview);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneview);
        window.show();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }}
    }

    @FXML
    private void Home(MouseEvent event) {
    }
    @FXML
    private void Feedbacks(MouseEvent event) {
    }
    @FXML
    private void Suggestion(MouseEvent event) {
    }
  

    @FXML
    private void Supprimer(ActionEvent event) {      
        SuggestionService sv = new SuggestionService();
        ObservableList<Suggestion> SelectedRows, allpeople;

        allpeople = table.getItems();
        // il donne les ligne qui vous avez déja séléctionner
        SelectedRows = table.getSelectionModel().getSelectedItems();

        for (Suggestion gg : SelectedRows) {
            allpeople.remove(gg);
            sv.supprimerSuggestion(gg.getId());
        }
    }

    @FXML
    private void Ajouter(ActionEvent event) {
        try {
            javafx.scene.Parent tableview = FXMLLoader.load(getClass().getResource("AddSugg.fxml"));
            Scene sceneview = new Scene(tableview);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(sceneview);
            window.show();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    @FXML
    private void modify(ActionEvent event) throws IOException {
       Suggestion M = table.getSelectionModel().getSelectedItem();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifySugg.fxml"));
     Parent root = loader.load();
     ModifySuggController scene2Controller = loader.getController();

          
              scene2Controller.setFondation(M.getFondation());
              scene2Controller.setDescription(M.getDescription());
              scene2Controller.setMail(M.getMail());
              scene2Controller.setID(M.getId());
                Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Hello World");
            stage.show();
            ((Node)(event.getSource())).getScene().getWindow().hide();
    }
       
      
    @FXML
    private void logoutClicked(ActionEvent event){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                                "Are you sure you wish to exit?", ButtonType.YES,
                                 ButtonType.NO);
        alert.setTitle("Exit Program");
        alert.setHeaderText(null);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.YES) {
            try {
                Stage stage;
                Parent indexPage = FXMLLoader.load(getClass().getResource("LoginFXML.fxml"));
                Scene scene = new Scene(indexPage);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(scene);
                 window.show();
            } catch (IOException ex) {
                Logger.getLogger(AfficherSuggBackController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    @FXML
    private void Chercher(ActionEvent event) {
         String text = ch.getText();
         SuggestionService sv = new SuggestionService();
              ObservableList<Suggestion> listu  = FXCollections.observableArrayList();
     try {
        
         
         for(Suggestion bb: sv.RechercherSugg(text))
             listu.add(bb);
            table.setItems(listu); 
     
     } catch (SQLException ex) {
         Logger.getLogger(AfficherSuggBackController.class.getName()).log(Level.SEVERE, null, ex);
     }   
    }
}
