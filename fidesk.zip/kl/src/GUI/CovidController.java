/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXTextField;
import Entities.Covid;
import Entities.FosUser;
import Services.CovidService;
import Services.FosUserServices;
import com.jfoenix.controls.JFXButton;
import utils.ConnexionBD;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author mon
 */
public class CovidController implements Initializable {

    @FXML
    private ComboBox<String> cbgenre;
    @FXML
    private TextField Name;
    @FXML
    private TextField Last_Name;
    @FXML
    private TextField Mail;
    @FXML
    private TextField Phone_Number;
     @FXML
    private Label testmail;
    @FXML
    private Label alertLabel;
    @FXML
    ObservableList<String> sexelist;
    @FXML
    private Label testtel;
       @FXML
    private JFXButton back1;
    Connection conn = ConnexionBD.getInstance().getCnx();
    

    public CovidController() {

    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        List<String> sexe = new ArrayList<>();
        sexe.add("Female");
        sexe.add("Male");
        sexe.add("Other");
        sexelist = FXCollections.observableList(sexe);
        cbgenre.setItems(sexelist);

    }

    @FXML
    private void AjouterCovid(ActionEvent event) throws SQLException, IOException {
        CovidService fs = new CovidService();
            String nom=Name.getText();
            String prenom=Last_Name.getText();
            String tel=Phone_Number.getText();
            String mail=Mail.getText();
            String sexe=cbgenre.getValue();
             try {
              if (nom.trim().length() < 1 || prenom.trim().length() < 1 || tel.trim().length() < 1|| mail.trim().length() < 1 ) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("Attention");
            alert.setContentText("Verifier les champs");

            alert.showAndWait();
        }
            Covid u = new Covid(nom,prenom,tel,mail,sexe);   
            fs.create(u);
            System.out.println("Ajout effectué avec succès");
            Parent home_page_parent = FXMLLoader.load(getClass().getResource("firstsy.fxml"));
            Scene home_page_scene = new Scene(home_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.hide(); //optional
            app_stage.setScene(home_page_scene);
            app_stage.show();
           }catch(IOException ex){
           System.out.println(""+ex);
       }


    }
        public static boolean checkTel(String tel) {

        if((tel.matches("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"))){
            return true;
        }

        return false;
    }

    @FXML
    private void verifTel(MouseEvent event) {
       CovidService fs = new CovidService();
        if (checkTel(testtel.getText())) {
            if (fs.CheckIfTelExist(testtel.getText())) {
                testtel.setTextFill(Paint.valueOf("RED"));
                testtel.setText("Tel already exists ");
            } else {
                testtel.setTextFill(Paint.valueOf("#0000FF"));
                testtel.setText("Tel valide");

            }

        } else {
            testtel.setTextFill(Paint.valueOf("RED"));
            testtel.setText("Wrong number ");
        }

    }

    public boolean checkMail(String a) {

        Boolean valide = false;
        int i, j, k;
        for (j = 1; j < a.length(); j++) {
            if (a.charAt(j) == '@') {
                if (j < a.length() - 4) {
                    for (k = j; k < a.length() - 2; k++) {
                        if (a.charAt(k) == '.') {
                            valide = true;
                        }
                    }
                }
            }
        }

        return valide;
    }
       @FXML
    private void verifMail(MouseEvent event) {
        CovidService fs = new CovidService();
        if (checkMail(Mail.getText())) {
            if (fs.CheckIfUserExist(Mail.getText())) {
                testmail.setTextFill(Paint.valueOf("RED"));
                testmail.setText("Utilisateur existe déjà ");
            } else {
                testmail.setTextFill(Paint.valueOf("#0000FF"));
                testmail.setText("Email valide");
            }
        } else {
            testmail.setTextFill(Paint.valueOf("RED"));
            testmail.setText("Vérifiez le format de votre adresse mail ");
        }

    }
       @FXML
    private void handleButtonAction(ActionEvent event) {
    
        if (event.getSource() == back1) {
            try {
                Parent home_page_parent = FXMLLoader.load(getClass().getResource("back.fxml"));
            Scene home_page_scene = new Scene(home_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.hide(); //optional
            app_stage.setScene(home_page_scene);
            app_stage.show();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        } 
        

    }


 
}
