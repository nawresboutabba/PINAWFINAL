/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import utils.ConnexionBD;
import Entities.Covid;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import utils.EmailAttachmentSender;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import utils.BCrypt;
import utils.SessionUser;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.mail.MessagingException;

/**
 *
 * @author hatem
 */
public class CovidService  {

    Connection conn = ConnexionBD.getInstance().getCnx();
    Statement stmt;
  
    public void create(Covid u) {

        try {

            String req = "INSERT INTO `covid`(`Name`, `Last_Name`, `Phone`, `Mail`, `Sexe`) VALUES (?,?,?,?,?)";
            PreparedStatement st = conn.prepareStatement(req);
            st.setString(1, u.getName());
            st.setString(2, u.getLastname());
            st.setString(3, u.getPhone());
            st.setString(4, u.getMail());
            st.setString(5, u.getSexe());
            EmailAttachmentSender.sendEmailWithAttachments(u.getMail(), "Support Covid-19", "<h1> Cher utilisateur,</h1></br> <p>Nous avons l'honneur de vous accueiller parmi notre communauté. </p> </br></br> <h4>Merci pour votre confiance,</h4> </br> <h3> L'équipe de Savers</h3>");
            st.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
     public void getmail() throws SQLException, MessagingException {
        // List<Covid> listP =new ArrayList<>();
         String req= "select Mail from covid where id = (select MAX(id) from covid) ";
         Statement st;
        try{ 
        st=conn.createStatement();
        ResultSet res= st.executeQuery(req);
        while (res.next()){
            Covid p=new Covid();
      EmailAttachmentSender.sendEmailWithAttachments(res.getString("Mail"), "Support Covid-19", "<h1> Dear user,</h1></br> <p>you have a serious problem you should call 190 . </p> </br></br> <h4>Nchlh lebess,</h4> </br> <h3> L'équipe de Savers</h3>");
        }
        }
        catch(SQLException ex) 
        {
            System.out.println(ex);}
      
     }
    public void send() {  
        
        try {
           // List<Covid> listP =getmail();
            //String mail=listP.getMail();
            //EmailAttachmentSender.sendEmailWithAttachments(mail, "Support Covid-19", "<h1> Dear user,</h1></br> <p>you have a serious problem you should call 190 . </p> </br></br> <h4>Nchlh lebess,</h4> </br> <h3> L'équipe de Savers</h3>");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public Boolean CheckIfUserExist(String mail) {
        boolean check = false;
        try {
            String req = "select * from covid where Mail=? ";
            PreparedStatement st = conn.prepareStatement(req);
            st.setString(1, mail);
            ResultSet rs = st.executeQuery();
            int i = 0;
            while (rs.next()) {
                i++;
                if (i == 1) {
                    check = true;
                } else {
                    check = false;
                }
            }
        } catch (Exception a) {
            a.printStackTrace();
        }
        return check;
    }
     public Boolean CheckIfTelExist(String tel) {
        boolean check = false;
        try {
            String req = "select * from covid where Phone=? ";
            PreparedStatement st = conn.prepareStatement(req);
            st.setString(1, tel);
            ResultSet rs = st.executeQuery();
            int i = 0;
            while (rs.next()) {
                i++;
                if (i == 1) {
                    check = true;
                } else {
                    check = false;
                }
            }
        } catch (Exception a) {
            a.printStackTrace();
        }
        return check;
    }

   
}
