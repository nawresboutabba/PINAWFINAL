/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;


import Entities.Feedback;
import java.util.List;

/**
 *
 * @author mon
 */
public interface IFeed {
     public int ajouterService(Feedback f);
     public int modifierFeedback(Feedback f);
     public void supprimerFeedback(int id);
     public List<Feedback> afficherFeedback();
   
    
}
