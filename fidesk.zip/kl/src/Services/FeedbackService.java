/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;


import Entities.Feedback;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.ConnexionBD;

/**
 *
 * @author mon
 */
public class FeedbackService {
     Connection cnx= ConnexionBD.getInstance().getCnx();
    public void ajouterFeed(Feedback f){
           try {
            String req = "INSERT INTO fed (ev, rating) VALUES ('" + f.getEvent_id() + "', '" + f.getRating() + "')";
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("Successful insertion!");
        } catch (SQLException ex) {
            System.out.println(ex);
            Logger.getLogger(ServiceMaterial.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    public List<Feedback> RechercherFeed(int event_id) throws SQLException {

        List<Feedback> listrecherche = new ArrayList<>();
        try {
            String req = "SELECT * FROM fed WHERE ev='" + event_id + "'";
            Statement stt = cnx.createStatement();
            ResultSet rs = stt.executeQuery(req);
            while (rs.next()) {
                Feedback p = new Feedback();
                p.setId(rs.getInt(1));
                p.setEvent_id(rs.getInt(3));
                p.setRating(rs.getInt(2));
                listrecherche.add(p);

            }
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listrecherche;
    }


    public int modifierFeedback(Feedback f) {
        int executeUpdate = 0;
      Connection cnx= ConnexionBD.getInstance().getCnx();
        try {
            PreparedStatement ps;
            String query = "UPDATE fed SET rating = ?,ev = ? WHERE id = ?";
            ps = cnx.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
           ps.setInt(1,f.getEvent_id());
            ps.setInt(2,f.getRating());
            executeUpdate = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return executeUpdate;
    }

    
    public void supprimerFeedback(int id) {
      Connection cnx= ConnexionBD.getInstance().getCnx();;
        try {
            PreparedStatement ps;
            String query = "DELETE FROM fed WHERE id = ?";
            ps = cnx.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

  
       public List<Feedback> afficherFeedback() throws SQLException {
         List<Feedback> listP =new ArrayList<>();
         String req= "SELECT * FROM fed";
         Statement st;
        try{ 
        st=cnx.createStatement();
        ResultSet res= st.executeQuery(req);
        while (res.next()){
            Feedback p=new Feedback();
            p.setId(res.getInt("id"));
            p.setRating(res.getInt("rating"));
            p.setEvent_id(res.getInt("ev"));
            listP.add(p);
        }
       System.out.println(listP);
        }
        catch(SQLException ex) 
        {
            System.out.println(ex);}
            return listP;
      
     }
       public void modifierFeed1(int id,int event_id,int rating) {

        try {

            String query = "UPDATE fed SET ev= '" + event_id + "',rating= '" + rating + "' WHERE id='" + id + "'";
            Statement ps = cnx.createStatement();
            ps.executeUpdate(query);
            System.out.println("Feedback has been modified");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    
    public void getFeedback(Feedback f) {

        String r = "select * from fed";
        try {
            Statement stt = cnx.createStatement();
            ResultSet rs = stt.executeQuery(r);
            while (rs.next()) {
                Feedback cl;
                cl = new Feedback();
                cl.setId(rs.getInt(1));
                cl.setRating(rs.getInt(2));
                cl.setEvent_id(rs.getInt(3));
            }

            rs.last();
            int nbr = rs.getRow();
            if (nbr != 0) {
                System.out.println("Id: " + f.getId() + " ,Rating: " + f.getRating() + " ,Event_id: " + f.getEvent_id());
            } else {
                System.out.println(" Feedbacks wasn't found ");
            }
        } catch (SQLException ex) {

        }

    }

    public void getFeedbackid(int id, Feedback f) {

        String r = "select * from fed where id='" + id + "'";
        try {
            Statement stt = cnx.createStatement();
            ResultSet rs = stt.executeQuery(r);
            while (rs.next()) {
                Feedback cl;
                cl = new Feedback();
                cl.setId(rs.getInt(1));
                    cl.setId(rs.getInt(1));
                cl.setRating(rs.getInt(2));
                cl.setEvent_id(rs.getInt(3));
            }

            rs.last();
            int nbr = rs.getRow();
                if (nbr != 0) {
                System.out.println("Id: " + f.getId() + " ,Rating: " + f.getRating() + " ,Event_id: " + f.getEvent_id());
            } else {
                System.out.println(" Feedbacks wasn't found ");
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void chercherParId(int id) {
        try {
            String query = "SELECT * FROM fed WHERE id='" + id + "'";
            Statement st = cnx.createStatement();
            ResultSet rst = st.executeQuery(query);
            rst.last();
            int nbr = rst.getRow();
            if (nbr != 0) {
                System.out.println("feedback was found ");
            } else {
                System.out.println("feedback wasn't found ");
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }
    }

  

    public void supprimerparID(int id) {

        try {
            String query = "DELETE FROM fed WHERE id= '" + id + "'";
            Statement st = cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("feedbacks with id = " + id + " was deleted");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }
    }


    
}
