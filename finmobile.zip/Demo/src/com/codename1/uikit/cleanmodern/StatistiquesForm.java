package com.codename1.uikit.cleanmodern;

import com.codename1.charts.ChartComponent;
import com.codename1.charts.models.CategorySeries;
import com.codename1.charts.renderers.DefaultRenderer;
import com.codename1.charts.renderers.SimpleSeriesRenderer;
import com.codename1.charts.util.ColorUtil;
import com.codename1.charts.views.PieChart;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import Services.Feedservice;
import Entities.Feedback;
import com.codename1.ui.Button;
import com.codename1.ui.layouts.BorderLayout;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class StatistiquesForm extends Form {

    public Feedback e;
    public int n = 0;
    public int nT = 0;

//**********************************************
    /**
     * Builds a category series using the provided values.
     *
     * @param titles the series titles
     * @param values the values
     * @return the category series
     */
    public CategorySeries buildCategoryDataset(String title, double[] values) {
        CategorySeries series = new CategorySeries(title);
        int k = 0;
        for (double value : values) {
            series.add("Nbre  " + ++k, value);
        }

        return series;
    }
//**************************************************

    /**
     * Creates a renderer for the specified colors.
     */
    private DefaultRenderer buildCategoryRenderer(int[] colors) {
        DefaultRenderer renderer = new DefaultRenderer();
        renderer.setLabelsTextSize(15);
        renderer.setLegendTextSize(15);
        renderer.setMargins(new int[]{20, 30, 15, 0});
        for (int color : colors) {
            SimpleSeriesRenderer r = new SimpleSeriesRenderer();
            r.setColor(color);
            renderer.addSeriesRenderer(r);
        }
        return renderer;
    }

    /**
     * ******** Afficher La liste des Abonnés Restau*
     */
    public StatistiquesForm(Form previous) {
      //Form sb = new Form(new BorderLayout());
        setTitle("Statistics ");

        ArrayList<Feedback> data = new ArrayList<Feedback>();
        Feedservice v = new Feedservice();
        Container cnt = new Container(BoxLayout.y());
        data = v.getAllFeedback();
        Label Rating = new Label("Ratings :");
        cnt.add(Rating);
        for (int i = 0; i < data.size(); i++) {

            Label l1 = new Label(String.valueOf(data.get(i).getRating()));

            cnt.add(l1);

            n += 1;

        }

//*****************************************
               Label AboTran = new Label("events :");
        cnt.add(AboTran);
         ArrayList<String> tester = new ArrayList<String>();
        
        for (int i = 0; i < data.size(); i++) {
                  tester.add(String.valueOf(data.get(i).getEvent_id()));
      
        }
         Set<String> mySet = new HashSet<String>(tester);
         ArrayList<String> finale = new ArrayList<String>(mySet);
         
          for (int i = 0; i < finale.size(); i++) {

            Label l1 = new Label(finale.get(i));

            cnt.add(l1);

            nT += 1;

        }
    

//*****************************************
        System.out.println(" Rating's number :" + n);
        System.out.println("event's number :" + nT);
        double[] values = new double[]{n, nT};

        // Set up the renderer
        int[] colors = new int[]{ColorUtil.BLUE, ColorUtil.MAGENTA};
        DefaultRenderer renderer = buildCategoryRenderer(colors);
        renderer.setZoomButtonsVisible(true);
        renderer.setZoomEnabled(true);
        renderer.setChartTitleTextSize(20);
        renderer.setDisplayValues(true);
        renderer.setShowLabels(true);
        SimpleSeriesRenderer r = renderer.getSeriesRendererAt(0);
        r.setGradientEnabled(true);
        r.setGradientStart(0, ColorUtil.BLUE);
        r.setGradientStop(0, ColorUtil.GREEN);
        r.setHighlighted(true);

        // Create the chart ... pass the values and renderer to the chart object.
        PieChart chart = new PieChart(buildCategoryDataset("Statistics", values), renderer);

        // Wrap the chart in a Component so we can add it to a form
        ChartComponent c = new ChartComponent(chart);

        add(c);
        add(cnt);
          Button app = new Button("back for app");
                        app.addActionListener((e) -> {
                            new home(previous).show();
                        });

          add(app);

        /*
 Style s = UIManager.getInstance().getComponentStyle("TitleCommand");
 FontImage icon = FontImage.createMaterial(FontImage.MATERIAL_WARNING, s);
//getToolbar().addCommandToLeftBar("Left", icon, (e) -> Log.p("Clicked"));
//getToolbar().addCommandToRightBar("Right", icon, (e) -> Log.p("Clicked"));
getToolbar().addCommandToOverflowMenu("Overflow", icon, (e) -> Log.p("Clicked"));
getToolbar().addCommandToSideMenu("Sidemenu", icon, (e) -> Log.p("Clicked"));
      
         */
//********************************
    }
}
