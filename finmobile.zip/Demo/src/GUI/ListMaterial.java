/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Entities.material;
import Services.ServiceMaterial;
import com.codename1.components.SpanLabel;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BoxLayout;
import java.util.List;

/**
 *
 * @author Memmicha
 */
public class ListMaterial extends Form {
 
     material m = new material();
   
    public ListMaterial(Form previous) {
        setTitle("List Materials");
        setLayout(BoxLayout.y());
        
        List <material> materials = ServiceMaterial.getInstance().getAllMaterial();
    
        for (int i = 0; i < materials.size(); i++) {
            Label l = new Label("Material N°"+i);
            addAll(l);
            material get = materials.get(i);
            add(addMaterial(get));
        }
        
        
       // getToolbar().addMaterialCommandToLeftBar("", FontImage.MATERIAL_ARROW_BACK, e-> previous.showBack());
    }   
    
     private Container addMaterial(material e){
          Container holder = new Container(BoxLayout.x());
          Container detaills = new Container(BoxLayout.y());
          
        
          Label l0=new Label ("idAddress:"+e.getId_address());
          Label l1=new Label ("nameAddress:"+e.getName_address());
          Label l2=new Label ("address:"+e.getAddress());
          Label l3=new Label ("description:"+e.getDescription());
    
          detaills.add(l0);
          detaills.add(l1);
          detaills.add(l2);
          detaills.add(l3);
          
          holder.add(detaills);
          return (holder);
     }
}

