/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import java.text.SimpleDateFormat;

/**
 *
 * @author cobwi
 */
public class ToolsUtilities {

    public static boolean DEBUG = true;
    public static SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
    public static String ServerIp = "http://localhost";
    public static String port = "80";

    public ToolsUtilities() {
        System.out.println("");
    }

}
