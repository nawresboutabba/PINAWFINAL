/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import Entities.user;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import utils.ConnexionBD;
import utils.PasswordUtils;

/**
 *
 * @author Memmicha
 */
public class UserController {
     Connection con;
        PreparedStatement preparedStatement;
        ResultSet resultSet;

    public UserController() {
        con =ConnexionBD.getInstance().getCnx();

    }
    
    
    
     private Statement ste;
  public void Add(user u) throws SQLException
    {
        PasswordUtils crypt = new PasswordUtils();
        PreparedStatement pre=con.prepareStatement("INSERT INTO user (id, username, firstName,lastName, email,password,roles) VALUES (?,?,?,?,?,?,?);");
        pre.setString(1, u.getUsername());
        pre.setString(2, crypt.hashPassword(u.getPassword()));
        pre.setString(3, u.getEmail());
        pre.setString(4, u.getLastName());
        pre.setString(5, u.getFirstName());
        pre.setString(6, u.getRoles());

        pre.executeUpdate();
    }
      
     public List<user> readAll() throws SQLException {
    List<user> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from user");
     while (rs.next()) { 
               
               String lastName=rs.getString("lastName");
               String firstName=rs.getString("firstName");
               String roles=rs.getString("role");
               user u=new user(lastName,firstName,roles);
     arr.add(u);
     }
    return arr;
    }

    public boolean delete(user u) throws SQLException {
        ste = con.createStatement();
        String requeteDelete ="DELETE FROM  `solidarity`.`user` WHERE `user` . username ='"+u.getUsername()+"'";
        return ste.executeUpdate(requeteDelete)==1;
 
    }

  
    public boolean update(String email,String password) throws SQLException {
        String query  ="UPDATE `solidarity`.`user` SET `pwd`=?  WHERE email =?";
        con.setAutoCommit(false);
        preparedStatement = con.prepareStatement(query);        
        preparedStatement.setString(1, password);
        preparedStatement.setString(2, email);
        return preparedStatement.executeUpdate()==1;
        
        
    }
    
    public boolean RechercherParId(int id) throws SQLException
    {
        ste=con.createStatement();
        ResultSet rs=ste.executeQuery("SELECT * FROM user where id="+ id);
        if (rs.next()) { 
               
               return true;
        }
        return false;
    }
    
    public boolean RechercherParLogin(String username) throws SQLException
    {
        ste=con.createStatement();
        ResultSet rs=ste.executeQuery("SELECT * FROM user where username="+ username);
        if (rs.next()) { 
               
               return true;
        }
        return false;
    }
}
