/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import Entities.user;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import utils.ConnexionBD;
import utils.PasswordUtils;

/**
 *
 * @author Memmicha
 */
public class loginController implements Initializable {

    @FXML
    private Label lblErrors;

    @FXML
    private TextField txtUsername;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnSignin;
    @FXML
    private Hyperlink btnForgot;
    @FXML
    private Button btnFB;
    @FXML
    private Button btnSignup;
    @FXML
    private AnchorPane rootPane;

    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    @FXML
    public void handleButtonAction(MouseEvent event) throws SQLException {

        if (event.getSource() == btnSignin) {
            //login here
            if (logIn().equals("Success")) {
                try {
                    String sql = "SELECT * FROM user Where login = ?";

                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.setString(1, txtUsername.getText());
                    resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        user u = new user();
                        u.setEmail(resultSet.getString("email"));
                        u.setId(resultSet.getInt("id"));
                        if (resultSet.getString("role").equals("foundation")) {

                            Node node = (Node) event.getSource();
                            Stage stage = (Stage) node.getScene().getWindow();
                            //stage.setMaximized(true);
                            stage.close();
                            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/GUI/foundation.fxml")));
                            stage.setScene(scene);
                            stage.show();
                        }
                    }
                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                }
                if (resultSet.getString("role").equals("admin")) {
                    try {
                        Node node = (Node) event.getSource();
                        Stage stage = (Stage) node.getScene().getWindow();
                        //stage.setMaximized(true);
                        stage.close();
                        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/GUI/Admin.fxml")));
                        stage.setScene(scene);
                        stage.show();
                    } catch (IOException ex) {
                        Logger.getLogger(loginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (resultSet.getString("role").equals("visitor")) {
                    try {
                        Node node = (Node) event.getSource();
                        Stage stage = (Stage) node.getScene().getWindow();
                        //stage.setMaximized(true);
                        stage.close();
                        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/GUI/Home.fxml")));
                        stage.setScene(scene);
                        stage.show();
                    } catch (IOException ex) {
                        Logger.getLogger(loginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
     /*   con = ConnexionBD.getCnx();
         if (con == null) {
            lblErrors.setTextFill(Color.TOMATO);
            lblErrors.setText("Server Error : Check");
        } else {
            lblErrors.setTextFill(Color.GREEN);
            lblErrors.setText("Server is up : Good to go");
        }*/
    }

    public loginController() {
        con = ConnexionBD.getCnx();
    }

    private String logIn() {
        PasswordUtils crypt = new PasswordUtils();
        String status = "Success";
        String login = txtUsername.getText();
        String password = txtPassword.getText();
        if (login.isEmpty() || password.isEmpty()) {
            setLblError(Color.TOMATO, "Empty credentials");
            status = "Error";
        } else {
            //query
            String sql = "SELECT * FROM user Where login = ?";
            try {
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, login);
                resultSet = preparedStatement.executeQuery();
                if (!resultSet.next()) {
                    setLblError(Color.TOMATO, "Enter Correct Email/Password");
                    status = "Error";
                } else {
                    if (crypt.checkPassword(password, resultSet.getString("pwd"))) {
                        setLblError(Color.GREEN, "Login Successful..Redirecting..");
                    } else {
                        setLblError(Color.TOMATO, "Enter Correct Email/Password");
                        status = "Error";
                    }

                }
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
                status = "Exception";
            }
        }

        return status;
    }

    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);
    }

    @FXML
    private void SignupButton(ActionEvent event) throws IOException {
        if (event.getSource() == btnSignup) {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("/fxml/Signup.fxml"));
            rootPane.getChildren().setAll(pane);
        }

    }

    @FXML
    private void redirectForgetPassword(MouseEvent event) throws IOException {

        if (event.getSource() == btnForgot) {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("/fxml/ForgotPassword.fxml"));
            rootPane.getChildren().setAll(pane);
        }

    }

}
