/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Memmicha
 * @param <material>
 */
public interface IServiceMaterial<material> {
    void ajouterMaterial1(material m) throws SQLException;
    void modifierMaterial1(material m) throws SQLException;
    void UpdateMaterial(material m ) throws SQLException;
    void supprimerparID (material m) throws SQLException;
    void supprimerparAddress(material m) throws SQLException;
    List<material> RechercherMaterial(material m) throws SQLException;
    List <material> getListMat() throws SQLException;
    
}
