/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Memmicha
 * @param <transaction>
 */
public interface IServiceTransaction<transaction> {
    void AddTransaction(transaction t) throws SQLException;
    void ajouter(transaction t) throws SQLException;
    void modifierTransaction(transaction t) throws SQLException;
    void supprimerparID(transaction t) throws SQLException;
    void supprimerparName(transaction t) throws SQLException;
    void UpdateTransaction(transaction t) throws SQLException;
    List<transaction> RechercherTransaction(transaction t) throws SQLException;
    List <transaction> getListTran() throws SQLException;
}
