/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;



import Entities.Suggestion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.ConnexionBD;


/**
 *
 * @author mon
 */
public class SuggestionService  {
     Connection cnx= ConnexionBD.getInstance().getCnx();
   
    public void ajouterSuggestion(Suggestion s) {
                 try {
            String req = "INSERT INTO sug (mail, nom_fondation, description) VALUES ('" + s.getMail() + "', '" + s.getFondation() + "', '" + s.getDescription() + "')";
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("Successful insertion!");
        } catch (SQLException ex) {
            System.out.println(ex);
            Logger.getLogger(ServiceMaterial.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
       public List<Suggestion> RechercherSugg(String Fondation) throws SQLException {

        List<Suggestion> listrecherche = new ArrayList<>();
        if (Fondation.equals("")) {
        }
        try {
            String req = "SELECT * FROM sug WHERE nom_fondation='" + Fondation + "'";
            Statement stt = cnx.createStatement();
            ResultSet rs = stt.executeQuery(req);
            while (rs.next()) {
                Suggestion p = new Suggestion();
                p.setId(rs.getInt(1));
                p.setFondation(rs.getString(3));
                p.setMail(rs.getString(2));
                p.setDescription(rs.getString(4));
                listrecherche.add(p);

            }
        } catch (SQLException ex) {
            Logger.getLogger(SuggestionService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listrecherche;
    }

    public void chercherParFon(String fondation) {
        try {
            String query = "SELECT * FROM sug WHERE nom_fondation ='" + fondation + "'";
            Statement st = cnx.createStatement();
            ResultSet rst = st.executeQuery(query);
            rst.last();
            int nbr = rst.getRow();
            if (nbr != 0) {
                System.out.println(fondation + " found ");
            } else {
                System.out.println(fondation + " not found");
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }

    }
        public void chercherParId(int id) {
        try {
            String query = "SELECT * FROM sug WHERE id='" + id + "'";
            Statement st = cnx.createStatement();
            ResultSet rst = st.executeQuery(query);
            rst.last();
            int nbr = rst.getRow();
            if (nbr != 0) {
                System.out.println("Suggestion was found ");
            } else {
                System.out.println("Suggestion wasn't found ");
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }
    }
            public void modifierSugg1(int id, String fondation, String mail, String Description) {

        try {

            String query = "UPDATE sug SET nom_fondation= '" + fondation + "',mail= '" + mail + "',description= '" + Description + "' WHERE id='" + id + "'";
            Statement ps = cnx.createStatement();
            ps.executeUpdate(query);
            System.out.println("Suggestion has been modified");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

     
    public int modifierSuggestion(Suggestion s) {
        int executeUpdate = 0;
     Connection cnx= ConnexionBD.getInstance().getCnx();
        try {
            PreparedStatement ps;
            String query = "UPDATE sug SET mail = ?,nom_fondation = ?,description = ? WHERE id = ?";
            ps = cnx.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setString (1, s.getMail());
            ps.setString (2, s.getFondation());
            ps.setString (3, s.getDescription());
            ps.setInt    (5, s.getId());
            executeUpdate = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SuggestionService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return executeUpdate;
    }
    public void getSugg(Suggestion f) {

        String r = "select * from sug";
        try {
            Statement stt = cnx.createStatement();
            ResultSet rs = stt.executeQuery(r);
            while (rs.next()) {
                Suggestion cl;
                cl = new Suggestion();
                cl.setId(rs.getInt(1));
                cl.setFondation(rs.getString(2));
                cl.setMail(rs.getString(3));
                 cl.setDescription(rs.getString(4));
            }

            rs.last();
            int nbr = rs.getRow();
            if (nbr != 0) {
                System.out.println("Id: " + f.getId() + " ,Fondation: " + f.getFondation() + " ,mail: " + f.getMail()+ " ,descrirption: " + f.getDescription());
            } else {
                System.out.println(" Suggestions wasn't found ");
            }
        } catch (SQLException ex) {

        }

    }
    
    public void supprimerSuggestion(int id) {
     Connection cnx= ConnexionBD.getInstance().getCnx();
        try {
            PreparedStatement ps;
            String query = "DELETE FROM sug WHERE id = ?";
            ps = cnx.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SuggestionService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

 
      public List<Suggestion> afficherSuggestion() throws SQLException{
         List<Suggestion> listP =new ArrayList<>();
         String req= "SELECT * FROM sug";
         Statement st;
        try{ 
        st=cnx.createStatement();
        ResultSet res= st.executeQuery(req);
        while (res.next()){
           Suggestion p=new Suggestion();
            p.setId(res.getInt("id"));
            p.setMail(res.getString("mail"));
            p.setDescription(res.getString("description"));
            p.setFondation(res.getString("nom_fondation"));
            listP.add(p);
        }
       System.out.println(listP);
        }
        catch(SQLException ex) 
        {
            System.out.println(ex);}
            return listP;
      
     }
      public String getName(int id) {
        String empName = "";
          int executeUpdate = 0;
        Connection cnx= ConnexionBD.getInstance().getCnx();
      
        try {
            PreparedStatement ps,jobPs;
            String query = "select nom_fondation from suggestion where id = ?";
           
            ps = cnx.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                empName = rs.getString(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SuggestionService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return empName;
    }
    }

  
  
    

