/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.util.Objects;

/**
 *
 * @author mon
 */
public class Suggestion {
   private int id ;
   private String mail;
   private String fondation;
   private String  description;

    public Suggestion(int id, String mail, String fondation, String description) {
        this.id = id;
        this.mail = mail;
        this.fondation = fondation;
        this.description = description;
    }

    public Suggestion(String mail, String fondation, String description) {
        this.mail = mail;
        this.fondation = fondation;
        this.description = description;
    }

 

    public Suggestion() {
    }

    @Override
    public String toString() {
        return "Suggestion{" + "id=" + id + ", mail=" + mail + ", fondation=" + fondation + ", description=" + description + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getFondation() {
        return fondation;
    }

    public void setFondation(String fondation) {
        this.fondation = fondation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Suggestion other = (Suggestion) obj;
        if (!Objects.equals(this.fondation, other.fondation)) {
            return false;
        }
        if (!Objects.equals(this.mail, other.mail)) {
            return false;
        }
        if (!Objects.equals(this.description, other.description)) {
            return false;
        }
    
        return true;
    }
}
